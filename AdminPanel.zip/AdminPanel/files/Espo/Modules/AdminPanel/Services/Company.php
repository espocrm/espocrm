<?php

namespace Espo\Modules\AdminPanel\Services;

use Espo\Core\Services\Record;

class Company extends Record
{
}
