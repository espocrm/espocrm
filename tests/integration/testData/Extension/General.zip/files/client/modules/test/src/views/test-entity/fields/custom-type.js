
Espo.define('Test:Views.TestEntity.Fields.CustomType', 'Views.Fields.Enum', function (Dep) {

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);
        },

    });

});
